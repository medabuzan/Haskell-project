cd ../src
runhaskell Test/Tests.hs
cd ../scripts