./compile.sh
../out/raytracer $@